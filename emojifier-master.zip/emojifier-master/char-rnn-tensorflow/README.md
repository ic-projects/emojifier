# char-rnn-tensorflow
Multi-layer Recurrent Neural Networks (LSTM, RNN) for character-level language models in Python using Tensorflow.

Inspired from Andrej Karpathy's [char-rnn](https://github.com/karpathy/char-rnn).

# Requirements
- [Tensorflow](http://www.tensorflow.org)

# Basic Usage
Run test.sh to sample, hopefully it runs on your system.

Running train.sh will re-continue the training, running firststart.sh will redo all weights and models and restart training

Currently using only reddit comments
