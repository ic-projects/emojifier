#!/bin/bash
python //homes/ljs116/tensorflow/char-rnn-tensorflow/sample.py --save_dir=//homes/ljs116/tensorflow/char-rnn-tensorflow/save/ --sample=5 -n=800



